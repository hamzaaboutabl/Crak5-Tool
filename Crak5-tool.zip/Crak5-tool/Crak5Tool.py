from tqdm import tqdm , trange
from time import *
import socket
from termcolor import colored
from datetime import datetime
import sys
import hashlib
import os
import curses
from curses import KEY_RIGHT, KEY_LEFT, KEY_UP, KEY_DOWN
from random import randint
#############################
r = '\033[1;31m'
g = '\033[1;32m'
y = '\033[1;33m'
b = '\033[1;34m'
c = '\033[1;36m'
os.system('clear')
#############################
def Snake():
    os.system('python3 main.py')
    return Crak5()
#############################
def banner():
    print("\033[1;36m ██████╗██████╗  █████╗ ██╗  ██╗ \033[1;32m██████████████╗")
    print("\033[1;36m██╔════╝██╔══██╗██╔══██╗██║ ██╔╝ \033[1;32m██████████████║")
    print("\033[1;36m██║     ██████╔╝███████║█████╔╝  \033[1;32m████╔═════════╝")
    print("\033[1;36m██║     ██╔══██╗██╔══██║██╔═██╗  \033[1;32m████║")
    print("\033[1;36m╚██████╗██║  ██║██║  ██║██║  ██╗ \033[1;32m██████████████╗")
    print("\033[1;36m ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝ \033[1;32m██████████████║")
    print("                                 \033[1;32m╚══════════███║")
    print("                                 \033[1;32m           ███║")
    print("\033[1;37mDon't       Trust      Hackers   \033[1;32m\033[1;32m██████████████║")
    print("\033[1;34m──────────────────────────────╼  \033[1;32m██████████████║")
    print("                                 \033[1;32m╚═════════════╝")
#############################
def Crypto5():
    try:
        keys = 'mbgijkxacdrponzystvuelfhqw'
        value = keys[-1] + keys[0:-1]
        encrytDict = dict(zip(keys, value))
        decryptDict = dict(zip(value, keys))

        print("\033[1;31m╭───[\033[1;32mCrypto5\033[1;31m]")
        print("\033[1;31m│")
        message = input("\033[1;31m╰───╼\033[1;33m $ ")

        print("\033[1;31m╭───[\033[1;36mEnter Option: \033[1;32m[1]\033[1;36m Encrypt \033[1;31m[2]\033[1;36m Decrypt\033[1;31m]")
        print("\033[1;31m│")
        mode = input("\033[1;31m╰───╼\033[1;33m $ ")

        if mode == '1':
            newMessage = ''.join([encrytDict[letter] 
                                  for letter in message.lower()])
        if mode == '2':
            newMessage = ''.join([decryptDict[letter] 
                                  for letter in message.lower()])
        if message == 'back':
            return Crak5()
    

        print (newMessage)
        return Crypto5()

        Crypto5()
    except KeyError:
        print("\033[1;31m[-] \033[1;36mError This Tool Crypts Only Strings")
#############################
def IPTracker():
    import time
    import json
    import requests
    from prettytable import PrettyTable
    try:
        print("\033[1;31m╭───[\033[1;32mEnter IP To Scan\033[1;33m\033[1;31m]")
        print("\033[1;31m│")
        ip = input("\033[1;31m╰───╼\033[1;33m $ ")
        api = 'http://ip-api.com/json/'
        res = requests.get(api + ip)
        data = res.json()
        print('\033[1;92mStatus\033[1;96m──────>\033[1;95m',data['status'])
        print('\n')
        print('\033[1;92mIP\033[1;96m──────────>\033[1;95m',data['query'])
        print('\n')
        print('\033[1;92mCountry\033[1;96m──────>\033[1;95m',data['country'])
        print('\n')
        print('\033[1;92mCity\033[1;96m────────>\033[1;95m',data['city'])
        print('\n')
        print('\033[1;92mRegion\033[1;96m──────>\033[1;95m',data['region'])
        print('\n')
        print('\033[1;92mtimezone\033[1;96m─────>\033[1;95m',data['timezone'])
        print('\n')
        print('\033[1;92mLat\033[1;96m─────────>\033[1;95m',data['lat'])
        print('\n')
        print('\033[1;92mLon\033[1;96m─────────>\033[1;95m',data['lon'])
        print('\n')
        print('\033[1;92mISP\033[1;96m─────────>\033[1;95m',data['isp'])
        print('\n')

        return Crak5()
    except KeyError:
        return Crak5()

#############################
def carracing():
    os.system('cd racing-game && python3 startup.py')
    return Crak5()
#############################
def networkscan():
    from N4Tools.Design import ThreadAnimation,Color, AnimationTools, Animation
    from N4Tools.terminal import terminal
    from requests import get
    import socket, nmap, getmac
    from rich.live import Live
    from rich import box
    from rich.table import Table

    terminal = terminal()
    CO = Color()
    AN = Animation()

    class networkInfo:
        def __init__(self):
            hosts = self.internal_ip.split('.')
            hosts = '.'.join(hosts[:-1]) + '.0/24'
            self.Nmap = nmap.PortScanner()
            self.Nmap.scan(hosts=hosts, arguments='-sP')
        @property
        def internal_ip(self):
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip

        @property
        def external_ip(self):
            return get('http://ipinfo.io/json').json()

        def IpInfo(self):
            table = Table(expand=True, title='IP INFO',box=box.SQUARE_DOUBLE_HEAD)
            table.add_column("option",style='purple')
            table.add_column("value",style='cyan')

            with Live(table, refresh_per_second=1):
                table.add_row("internal", f"{self.internal_ip}")
                for key,val in self.external_ip.items():
                    if key not in ['hostname','readme']:
                        key = key.replace('ip','external')
                        table.add_row(key, val)

        def wifiUsers(self):
            table = Table(expand=True,title='WIFI USERS',box=box.SQUARE_DOUBLE_HEAD,show_lines=True)
            table.add_column("Device",style='cyan')
            table.add_column("Devices IP",style='cyan')
            table.add_column("mac addrres",style='cyan')

            with Live(table, refresh_per_second=1):
                for ip in self.Nmap.all_hosts():
                    device_name = socket.getfqdn(ip)
                    device_name = '[red]Unknow' if device_name == ip else device_name
                    mac = getmac.get_mac_address(ip=ip)
                    table.add_row(f"{device_name}", f"{ip}", f"{mac if mac else '[red]Unknow'}")

    text_anim = AnimationTools.set_text_anim('Scanning all network...')
    kwargs = (lambda **kwargs:kwargs)(text=text_anim)
    @ThreadAnimation(Animation=AN.Loading,kwargs=kwargs,timer=.15)
    def result(Thread):
        obj = networkInfo()
        return obj
        
    if __name__=='__main__':
        obj = result()
        obj.IpInfo()
        obj.wifiUsers()
#############################
def lsmap():
    os.system('tree')
    return Crak5()
def Hash_God():
    print("\033[1;31m╭───[\033[1;32mHash-God\033[1;31m]")
    print("\033[1;31m│")
    opt = input("\033[1;31m╰───╼\033[1;33m $ ")
    if opt == '1':
        print("\033[1;31m╭───[\033[1;32mHash_God\033[1;33m@\033[1;36mSHA-256\033[1;31m]")
        print("\033[1;31m│")
        text = input("\033[1;31m╰───╼\033[1;33m $ ")
        encoded_txt = hashlib.sha256(text.encode())
        print("\033[1;31m╭───[\033[1;32mHashed Text\033[1;31m]")
        print("\033[1;31m│")
        print("\033[1;31m╰───╼\033[1;33m $ ",(encoded_txt.hexdigest()))
        return Hash_God()
    if opt == '2':
        print("\033[1;31m╭───[\033[1;32mHash_God\033[1;33m@\033[1;36mSHA-512\033[1;31m]")
        print("\033[1;31m│")
        text = input("\033[1;31m╰───╼\033[1;33m $ ")
        encoded_txt = hashlib.sha512(text.encode())
        print("\033[1;31m╭───[\033[1;32mHashed Text\033[1;31m]")
        print("\033[1;31m│")
        print("\033[1;31m╰───╼\033[1;33m $ ",(encoded_txt.hexdigest()))
        return Hash_God() 
    if opt == '3':
        print("\033[1;31m╭───[\033[1;32mHash_God\033[1;33m@\033[1;36mSHA-1\033[1;31m]")
        print("\033[1;31m│")
        text = input("\033[1;31m╰───╼\033[1;32m $ ")
        encoded_txt = hashlib.sha1(text.encode())
        print("\033[1;31m╭───[\033[1;32mHashed Text\033[1;31m]")
        print("\033[1;31m│")
        print("\033[1;31m╰───╼\033[1;33m $ ",(encoded_txt.hexdigest()))
        return Hash_God()
    if opt == '4':
        print("\033[1;31m╭───[\033[1;32mHash_God\033[1;33m@\033[1;36mMD-5\033[1;31m]")
        print("\033[1;31m│")
        text = input("\033[1;31m╰───╼\033[1;33m $ ")
        encoded_txt = hashlib.md5(text.encode())
        print("\033[1;31m╭───[\033[1;32mHashed Text\033[1;31m]")
        print("\033[1;31m│")
        print("\033[1;31m╰───╼ \033[1;33m$ ",(encoded_txt.hexdigest()))
        return Hash_God()
    if opt == 'help':
        print("\033[1;36mSteps\n")
        print("\033[1;33m1: Choose Option     2: Type The Text You Want To Hash\n")
        print("\033[1;36mCommands          \033[1;32mDescription\n")
        print("\033[1;33mback              Return To Main Menu\n")
        print("\033[1;33mexit              Exit Crak5 Tool\n")
        print("\033[1;33mshow options      Display hashing options\n")
        return Hash_God()
    if opt == 'back':
        return Crak5()
    if opt == 'exit':
        print('\033[1;96mGoodBye...!')
        exit()
    if opt == 'show options':
        print ("\033[1;32m[ 1 ]\033[1;36m SHA-256\n")
        print ("\033[1;32m[ 2 ]\033[1;36m SHA-512\n")
        print ("\033[1;32m[ 3 ]\033[1;36m SHA-1\n")
        print ("\033[1;32m[ 4 ]\033[1;36m MD-5\n")
    else:
        print("\033[1;31m[-] \033[1;36mCommand Not Found")
    return Hash_God()        
#############################
def Dino():
        os.system("python3 main1.py")
#############################
def Port_Scanner():
    print("\033[1;31m╭───[\033[1;32mEnter IP To Scan\033[1;33m\033[1;31m]")
    print("\033[1;31m│")
    ip = input("\033[1;31m╰───╼\033[1;33m $ ")
    t1 = datetime.now()
    print('\033[1;32mScanning Started Please Wait...\n')
    sleep(1)
    ##############
    try:
        for port in range(1,6553):
            s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            if(s.connect_ex((ip,port)))==0:
                try:
                    serv=socket.getservbyport(port)
                except socket.error:
                    serv="\033[1;31mUnknown Service\n"
                print("\033[1;92mPort \033[1;96m%s \033[1;33mOpen Service\033[1;36m──────>\033[1;95m%s \n"%(port,serv))
            t2=datetime.now()
            t3=t2-t1
        print('\033[1;94mScanning Completed On\033[1;96m──────>\033[1;97m%s'%t3)
    except KeyboardInterrupt:
        print("GoodBye...!")
    return Crak5()
#############################
def help():
    print("\033[1;96m╭───────────────────────────────────────────────────────────────╮")
    print("\033[1;96m│ \033[1;97mCommands:                                                     \033[1;96m│")
    print("\033[1;96m│\033[1;92m────────────────────────────────────────────────────────────── \033[1;96m│")
    print("\033[1;96m│ \033[1;93mclear \033[1;96m ─────────>  \033[1;97mclear the screen                           \033[1;96m│                                    ")                            
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mexit   \033[1;96m─────────>  \033[1;97mshut down Crak5                            \033[1;96m│                                    ")
    print("\033[1;96m│                                                               \033[1;96m|                          ")
    print("\033[1;96m│ \033[1;93mlsmap  \033[1;96m─────────>  \033[1;97mmaps your list directory                   \033[1;96m|        ")                   
    print("\033[1;96m|                                                               \033[1;96m│")               
    print("\033[1;96m│ \033[1;93muse   \033[1;96m ─────────> \033[1;97mto use any module                           \033[1;96m│                           ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;97mTools:                                                        \033[1;96m│")
    print("\033[1;96m│\033[1;92m────────────────────────────────────────────────────────────── \033[1;96m│")
    print("\033[1;96m│ \033[1;93mPort_Scanner  \033[1;96m─────────>  \033[1;97mto scan open ports                  \033[1;96m│                            ")      
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mNetScan    \033[1;96m─────────>  \033[1;97mScans The Entire Network               \033[1;96m│")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mHash_God   \033[1;96m─────────>  \033[1;97mto hash any text                       \033[1;96m│                               ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mIPTracker  \033[1;96m─────────>  \033[1;97mGets All Information About Any IP      \033[1;96m│                               ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mCrypto5    \033[1;96m─────────>  \033[1;97mCrak5 Crypting algorithm               \033[1;96m│                               ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;97mGames:                                                        \033[1;96m│")
    print("\033[1;96m│\033[1;92m────────────────────────────────────────────────────────────── \033[1;96m│")
    print("\033[1;96m│ \033[1;93mSnake  \033[1;96m ─────────>   \033[1;97mascii snake game                         \033[1;96m│                                 ")      
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mDino   \033[1;96m ─────────>   \033[1;97mchrome dino game                         \033[1;96m│")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mCarRace\033[1;96m ─────────>   \033[1;97mGUI Car Racing Game                      \033[1;96m│")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;97mAbout Tool:                                                   \033[1;96m│")
    print("\033[1;96m│\033[1;92m────────────────────────────────────────────────────────────── \033[1;96m│")
    print("\033[1;96m│ \033[1;93mDeveloper \033[1;96m  ─────────>  \033[1;97m Anonymous                            \033[1;96m│                                    ")      
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93msoceity    \033[1;96m ─────────>  \033[1;97m Crak5                                \033[1;96m│                                       ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;97mAbout Crak5:                                                  \033[1;96m│")
    print("\033[1;96m│\033[1;92m────────────────────────────────────────────────────────────── \033[1;96m│")
    print("\033[1;96m│ \033[1;93msoceity   \033[1;96m ─────────> \033[1;97m Crak5                                  \033[1;96m|                                         ")      
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mDeepWeb   \033[1;96m ─────────> \033[1;97m ?                                      \033[1;96m│                                               ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mGitHub    \033[1;96m ─────────> \033[1;97m ?                                      \033[1;96m|                                              ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;97mHow To Use Tools And Games:                                   \033[1;96m│")
    print("\033[1;96m│\033[1;92m────────────────────────────────────────────────────────────── \033[1;96m│")
    print("\033[1;96m│ \033[1;93mPort_Scanner \033[1;96m ─────────>   \033[1;97muse Port_Scanner                   \033[1;96m|                            ")      
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mNetScan      \033[1;96m ─────────>   \033[1;97muse NetScan , Wait 1minute         \033[1;96m|                            ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mHash_God     \033[1;96m ─────────>  \033[1;97m use Hash_God,Type help In Tool     \033[1;96m|                               ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mSnake        \033[1;96m ─────────>  \033[1;97m use Snake                          \033[1;96m|                                  ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mDino         \033[1;96m ─────────>  \033[1;97m use Dino                           \033[1;96m|                                  ")
    print("\033[1;96m│                                                               \033[1;96m│") 
    print("\033[1;96m│ \033[1;93mhow to start Dino\033[1;96m ─────────>  \033[1;97m type space to start            \033[1;96m|                                  ")
    print("\033[1;96m│                                                               \033[1;96m│") 
    print("\033[1;96m│ \033[1;93mDino Controls\033[1;96m ─────────>  \033[1;97m jump: space    down: down-arrow    \033[1;96m|                                  ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mIPTracker    \033[1;96m ─────────>  \033[1;97m use IPTracker                      \033[1;96m|                                  ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mCarRace      \033[1;96m ─────────>  \033[1;97m use CarRace                        \033[1;96m|                                  ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mCrypto5      \033[1;96m ─────────>  \033[1;97m use Crypto5                        \033[1;96m|                                  ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mCrypto5 help \033[1;96m ─────────>  \033[1;97m 1:Type your text , choose option   \033[1;96m|                                  ")
    print("\033[1;96m│                                                               \033[1;96m│")
    print("\033[1;96m│ \033[1;93mCrypto5 commands \033[1;96m ─────────>  \033[1;97m type:back to return home       \033[1;96m|                                  ")
    print("\033[1;96m╰───────────────────────────────────────────────────────────────╯")
    return Crak5()
#############################
def clear():
    os.system('clear')
    banner()
    Crak5()
#############################
def Crak5():
    try:        
        print("\033[1;31m╭───[\033[1;32m",name+"\033[1;33m @ \033[1;36mCrak5\033[1;31m ]")
        print("\033[1;31m│")
        opt = input("\033[1;31m╰───╼\033[1;33m $ ")
        if opt == 'help':
            return help()
        if opt == 'clear':
            return clear()
        if opt == 'exit':
            print('\033[1;96mGoodBye...!')
            exit()
        if opt == 'use Port_Scanner':
            return Port_Scanner()
        if opt == 'use Hash_God':
            return Hash_God()
        if opt == 'ls':
            os.system('ls\n')
            return Crak5()
        if opt == 'lsmap':
            return lsmap()
            os.system('tree')
            return Crak5()
        if opt == 'use Snake':
            return Snake()
        if opt == 'use Dino':
            return Dino()
        if opt == 'use NetScan':
            return networkscan()
        if opt == 'use CarRace':
            return carracing()
        if opt == 'use IPTracker':
            return IPTracker()
        if opt == 'use Crypto5':
            return Crypto5()
        else:
            print("\033[1;31m[-] \033[1;36mCommand Not Found")
            return Crak5()
    except KeyboardInterrupt:
        print('\033[1;96mGoodBye...!')
        exit()
#############################
print("\033[1;31m╭───[\033[1;32minput your name\033[1;31m]")
print("\033[1;31m│")
name = input("\033[1;31m╰───╼\033[1;33m $ ")
os.system('clear')
banner()
Crak5()